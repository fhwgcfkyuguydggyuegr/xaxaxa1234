﻿using System;

namespace Maksim
{
    class MainClass
    {
        private static object гимназия;

        public static void Main(string[] args)
        {
            //string strO = "+---+\n|   |\n|   |\n|   |\n+---+\n\n";
            //Console.Write(strO);

            //string strT = "+---+\n  | \n  | \n  | \n\n";
            //Console.Write(strT);

            //string strE = "+---+\n+ \n+++++  \n+\n+---+      \n\n";
            //Console.Write(strE);

            //string strM = "mm mm\nm m m\nm m m\nm   m\nm   m\n\n";
            //Console.Write(strM);

            //string strC = "+---+\n|   \n|   \n|   \n+---+\n\n";
            //Console.Write(strC);

            //string strH = "   $   $   \n $ $ $ $ $  \n   $   $\n $ $ $ $ $ \n   $   $ \n\n";
            //Console.Write(strH);

            //string strQ ="5 5 5 5 5 5 5\n5\n5\n5\n5\n5 5 5 5 5 5 5\n            5\n            5\n            5\n            5\n            5\n5 5 5 5 5 5 5 \n\n";
            //Console.Write(strQ)
            //Console.WriteLine("$$$ТАБЛИЦА СЛОЖЕНИЯ$$$");


            //for (int i = 1; i < 16; ++i)
            //{

            //    for (int j = 1; j < 16; j++)
            //    {
            //        Console.Write($"{i * j,-4 }");
            //    }
            //    Console.WriteLine();
            //    Console.WriteLine()





            ////// перевод с арабских чисел в римские числа
            //    int[] araabic = { 1000, 900, 500, 400, 100, 50, 40, 10, 9, 5, 4, 1 };
            //string[] rome = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };                                                                                                                           

            //Console.WriteLine("перевод с арабских чисел на римскиечис

            string name = "maksim";
            int age = 10;
            bool isEmploytd = false;
            bool isEmploytd2 = true;
            double weight = 42.41;
            int age4 = 13;

            Console.WriteLine($"Имя: {name}");
            Console.WriteLine($"Возраст: {age}");
            Console.WriteLine($"Вес: {weight}");
            Console.WriteLine($"Работает: {isEmploytd}");
            Console.WriteLine($"играешь на пк: {isEmploytd2}");
            Console.WriteLine($"количиства компюторав {age4}");
  
            double weight100 = 0.25;
            string name99 = " школа 54";

            Console.WriteLine($"кусков пици: {weight100}");
            Console.WriteLine($"названия школы{name99} ");

        }
    }

}










